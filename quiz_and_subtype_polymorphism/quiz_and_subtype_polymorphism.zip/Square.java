package classes;

public class Square extends Rectangle {

	// Constructor
	Square(int size) {
		super(size,size);
	}
	
    // Method
	public String toString() {
		return "I am a square";
	}
}
