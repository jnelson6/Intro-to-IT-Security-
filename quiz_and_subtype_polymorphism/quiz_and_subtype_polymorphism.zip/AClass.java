package classes;

public class AClass {

	public AClass() {	
	}
	
	public boolean readFile(String s) {
	  return true; }

	public String setValue(int i) {
		return "Called the setValue method in AClass";
	};
	
}
