package classes;

public class AnotherClass extends AClass {
	
	public AnotherClass() {	
	}
	
	public boolean readFile(String s) {
	  return false; }

	public String setValue(double i) {
		return "Called the setValue method in the class AnotherClass";
	};
	

}
